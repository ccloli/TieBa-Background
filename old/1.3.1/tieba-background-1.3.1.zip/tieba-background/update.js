var popup,
	server=parseInt(localStorage.tbbg_server)||0,
	serverlist=['http://ext.ccloli.com/tieba-background/update/'],
	version=chrome.runtime.getManifest().version;
if(location.protocol=='chrome-extension:'){
	popup=1;
}
else popup=0;

if(window.location.hash.indexOf('first_run')>=0){
	var node=document.querySelector('article');
		node.removeAttribute('align');
		node.innerHTML='感谢您使用 TieBa-Background，此弹窗为 TieBa-Background 的更新页面。当该窗口弹出时，请勿关闭该页面。当扩展程序完成检查更新后，若无更新，其会自动关闭；若有更新，则会提醒您下载更新。<br>如果您已了解，现在您可以关闭该页面了。';
	window.resizeTo(500,250);
}
else{
var xhr=new XMLHttpRequest();
xhr.open('GET',serverlist[server]+'?version='+version);
xhr.onreadystatechange=function(){
	if(xhr.readyState==4&&xhr.status==200){
		var j=JSON.parse(xhr.responseText);
		/*
		var j={
			"need_update":"true",
			"version":'1.3.1',
			"min_chrome_version":'23',
			"update_detail":['修改扩展程序安装方式'],
			"update_server":[{name:'下载地址 1',url:'http://ext.ccloli.com/tieba-background/update/update.zip'}],
			"update_webdrive":[{name:'Mega',url:'https://mega.co.nz/#F!KN03mZYa!HAESk2OmwhgZdzYlcLi5Mw'}]
		}
		*/
		if(j.need_update=='true'){
			var jdetail='',
				jserver='',
				jdrive='',
				text;
			for(var i=0;i<j.update_detail.length;i++){
				jdetail+='<li>'+j.update_detail[i]+'</li>';
			}
			for(var i=0;i<j.update_server.length;i++){
				jserver+='<li><a href="'+j.update_server[i].url+'" download="tieba-background-update-'+j.version+'.zip">'+j.update_server[i].name+'</a></li>';
			}
			for(var i=0;i<j.update_webdrive.length;i++){
				jdrive+='<li><a href="'+j.update_webdrive[i].url+'" target="_blank">'+j.update_webdrive[i].name+'</a></li>';
			}
			text='<p align="center" style="color:#f00">TieBa-Background 已有最新更新……<p><p>版本号：'+j.version+'</p><p>更新详情：</p><div><ol>'+jdetail+'</ol></div><p>请点击下面的链接下载更新，下载后请将其解压至扩展程序所在目录并覆盖文件，然后刷新扩展程序页。</p><p>服务器下载链接：</p><div><ul>'+jserver+'</ul></div><p>备用网盘下载链接：</p><div><ul>'+jdrive+'</ul></div><p>（修改更新方式请在 TieBa-Background 设置页修改）</p>';
			if(popup==1){
				var node=document.querySelector('article');
				node.removeAttribute('align');
				node.innerHTML=text;
				window.resizeTo(500,350);
			}
			else{
				var f=document.createElement('script');
				f.innerHTML='$.dialog.alert("<style>.dialogJ.dialogJfix{font-size:14px;color:#000;background:rgba(255,255,255,.5)!important;font-family:微软雅黑!important}.dialogJbody{padding:15px;word-break:initial;text-align:justify}</style>'+text+'",{title:"TieBa-Background Update notification",width:500})';
				document.body.appendChild(f);
				document.body.removeChild(f);
			}
		}
		else {
			if(popup==1){
				document.querySelector('article').innerHTML='TieBa-Background 暂无更新，正在关闭窗口……';
				window.close();
			}
		}
	}
}
xhr.send(); 
}