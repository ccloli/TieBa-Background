﻿if(window.localStorage.getItem('tbbg_setting')){
var tbbg_value=JSON.parse(window.localStorage.getItem('tbbg_setting')),
	t0=new Date().getTime(),
	node,
	doc=document.documentElement,
	bg,
	bg_white,
	seed,
	rel,
	num,
	per;
if(typeof document.getElementsByTagName('tbbg')[0]=='undefined'){
	node=document.createElement('tbbg');
	document.documentElement.appendChild(node);
}
else node=document.getElementsByTagName('tbbg')[0];
if(tbbg_value.imgnum>0&&tbbg_value.load_version=='1')run2();
else if(tbbg_value.imgnum>0)run();
function run(){
	console.log('%cTieBa-Background%c add background image function start.','color:#ff7f3e;text-decoration:underline','color:#ff7f3e');
	//var t0=new Date().getTime();
	doc=document.documentElement;
	doc.setAttribute('has_TBBG_extension','true');
	bg=document.createElement('div');
	bg.className='TBBG_background';
	//bg.setAttribute('extension-name','TieBa-Background');
	if(tbbg_value.imgstyle=='repeat'){
		bg.style.backgroundSize='auto';
		bg.style.backgroundRepeat='repeat';
	}
	else{
		bg.style.backgroundSize=tbbg_value.imgstyle;
		bg.style.backgroundRepeat='no-repeat';
	}
	bg.style.backgroundAttachment='fixed';
	bg.style.backgroundPosition=tbbg_value.imgx+' '+tbbg_value.imgy;
	//bg.style.opacity=(100-tbbg_value.imga)/100;
	node.appendChild(bg);
	bg_white=document.createElement('div');
	//bg_white.setAttribute('extension-name','TieBa-Background');
	bg_white.className='TBBG_bg_white';
	bg_white.style.background='rgba(255,255,255,'+tbbg_value.imga/100+')';
	node.appendChild(bg_white);
	num=parseInt(Math.random()*tbbg_value.imgnum+1);
	if(tbbg_value.topa=='true'){
		seed=document.createElement('div');
		seed.className='TBBG_top_white';
		//seed.setAttribute('extension-name','TieBa-Background');
		node.appendChild(seed);
	}
	show(num);
	if(tbbg_value.imgchg=='true'&&tbbg_value.imgnum>1){
		if(tbbg_value.imgpl=="true"){
			rel=document.createElement('div');
			rel.id='TBBG_preload';
			//rel.setAttribute('extension-name','TieBa-Background');
			node.appendChild(rel);
			per=0;
			setInterval(function(){
				if(per==1)show(num),per=0;
				else if(per==0)pl(),per=1;
			},tbbg_value.imgchgt*500);
		}
		else setInterval(function(){
			num=parseInt(Math.random()*tbbg_value.imgnum+1);
			show(num);
		},tbbg_value.imgchgt*1000);
	}
	con();
}
function show(num){
	bg.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
}
function pl(){
	num=parseInt(Math.random()*tbbg_value.imgnum+1);
	rel.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
}


function run2(){
	console.log('%cTieBa-Background%c add background image function start.','color:#ff7f3e;text-decoration:underline','color:#ff7f3e');
	var t0=new Date().getTime();
	doc=document.documentElement;
	doc.setAttribute('has_TBBG_extension','true');
	bg=document.createElement('div');
	bg.className='TBBG_background';
	//bg.setAttribute('extension-name','TieBa-Background');
	if(tbbg_value.imgstyle=='repeat'){
		bg.style.backgroundSize='auto';
		bg.style.backgroundRepeat='repeat';
	}
	else{
		bg.style.backgroundSize=tbbg_value.imgstyle;
		bg.style.backgroundRepeat='no-repeat';
	}
	bg.style.backgroundAttachment='fixed';
	bg.style.backgroundPosition=tbbg_value.imgx+' '+tbbg_value.imgy;
	bg.style.opacity=(100-tbbg_value.imga)/100;
	num=parseInt(Math.random()*tbbg_value.imgnum+1);
	bg.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
	node.appendChild(bg);
	if(tbbg_value.topa=='true'){
		seed=document.createElement('div');
		seed.className='TBBG_top_white';
		//seed.setAttribute('extension-name','TieBa-Background');
		node.appendChild(seed);
	}
	if(tbbg_value.imgchg=='true'&&tbbg_value.imgnum>1){
		if(tbbg_value.imgpl=="true"){
			rel=bg.cloneNode(true);
			rel.setAttribute('preload','true');
			doc.appendChild(rel);
			per=0;
			setInterval(function(){
				if(per==1)show_2(),per=0;
				else if(per==0)pl_2(),per=1;
			},tbbg_value.imgchgt*500);
		}
		else setInterval(function(){
			num=parseInt(Math.random()*tbbg_value.imgnum+1);
			bg.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
		},tbbg_value.imgchgt*1000);
	}

	(function(s){
		var x=document.createElement("style");
		x.textContent=s;
		x.setAttribute('extension-name','TieBa-Background');
		document.documentElement.appendChild(x);
	})(
			'.wrap1,.wrap2,.thread_theme_4,body[class*=skin]{background:none!important}.tb-editor-wrapper{background-color:rgba(244,244,244,.3)!important}@-webkit-keyframes bg_show{from{opacity:0}to{opacity:'+(100-tbbg_value.imga)/100+'}}@-webkit-keyframes bg_hide{from{opacity:'+(100-tbbg_value.imga)/100+'}to{opacity:0}}'
	);
	con();
}
function show_2(){
	if(bg.hasAttribute('preload')){
		bg.removeAttribute('preload');
		rel.setAttribute('preload','true');
	}
	else{
		rel.removeAttribute('preload');
		bg.setAttribute('preload','true');
	}
}
function pl_2(){
	num=parseInt(Math.random()*tbbg_value.imgnum+1);
	if(bg.hasAttribute('preload')){
		bg.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
	}
	else{
		rel.style.backgroundImage='url(chrome-extension://'+tbbg_value.id+'/'+num+'.jpg)';
	}
}
function con(){
	console.log('%cTieBa-Background%c 背景图片载入时间统计（自注入背景图片起开始计时至注入样式后停止计时）：'+(new Date().getTime()-t0)+'ms','color:#4a82f0;text-decoration:underline','color:#4a82f0');
}

}