// TieBa-Background 1.3.1
// Copyright (c) 2013-2014, 864907600cc. Some rights reserved.
// Released under the GPL license  http://www.gnu.org/licenses/gpl.html

var popup,
	response,
	node,
	server=parseInt(localStorage.tbbg_server)||0,
	serverlist=['http://ext.ccloli.com/tieba-background/update/','http://chrome.afraid.xxx/tieba-background/update/'],
	version=chrome.runtime.getManifest().version;
if(location.protocol=='chrome-extension:'){
	popup=1;
}
else popup=0;

function update_check(){
	var xhr=new XMLHttpRequest();
	xhr.open('GET',serverlist[server]+'?version='+version);
	xhr.onreadystatechange=function(){
		//console.log(xhr.readyState+' , '+xhr.status)
		if(xhr.readyState==4){
			if(xhr.status==200){
				response=JSON.parse(xhr.responseText);
		/*
		var response=JSON.parse(
		{
			"need_update":"true",
			"version":'1.3.1',
			"min_chrome_version":'23',
			"update_detail":['修改扩展程序安装方式'],
			"update_server":[{name:'下载地址 1',url:'http://ext.ccloli.com/tieba-background/update/update.zip'}],
			"update_webdrive":[{name:'Mega',url:'https://mega.co.nz/#F!KN03mZYa!HAESk2OmwhgZdzYlcLi5Mw'}]
		})
		*/
				if(response.need_update=='true'){
					update_confirm();
				}
				else{
					if(popup==1){
						document.querySelector('article').innerHTML='TieBa-Background 暂无更新，正在关闭窗口……';
						window.close();
					}
				}
			}
			else{
				if(server<serverlist.length-1){
					server++;
					document.querySelector('article').innerHTML='连接服务器出错，正在尝试访问其他更新服务器……';
					update_check();
				}
				document.querySelector('article').innerHTML='连接服务器出错，请检查您的网络设置后刷新页面……';
			}
		}
	}
	xhr.send(); 
}

function update_confirm(){
	var jdetail='',
		jserver='',
		jdrive='',
		text;
	for(var i=0;i<response.update_detail.length;i++){
		jdetail+='<li>'+response.update_detail[i]+'</li>';
	}
	for(var i=0;i<response.update_server.length;i++){
		jserver+='<li><a href="'+response.update_server[i].url+'" download="tieba-background-update-'+response.version+'.zip">'+response.update_server[i].name+'</a></li>';
	}
	for(var i=0;i<response.update_webdrive.length;i++){
		jdrive+='<li><a href="'+response.update_webdrive[i].url+'" target="_blank">'+response.update_webdrive[i].name+'</a></li>';
	}
	text='<p align="center" style="color:#f00">TieBa-Background 已有最新更新……<p><p>版本号：'+response.version+'</p><p>更新详情：</p><div><ol>'+jdetail+'</ol></div><p>请点击下面的链接下载更新，下载后请将其解压至扩展程序所在目录并覆盖文件，然后刷新扩展程序页。</p><p>服务器下载链接：</p><div><ul>'+jserver+'</ul></div><p>备用网盘下载链接：</p><div><ul>'+jdrive+'</ul></div>';
	if(popup==1){
		node=document.querySelector('article');
		node.removeAttribute('align');
		node.innerHTML=text;
		window.resizeTo(500,320+(response.update_detail.length*16));
		window.moveTo(9999,9999);
		var z=document.getElementsByTagName('a');
		for(var w=0;w<z.length;w++)z[w].onclick=function(){update_nextstep()};
	}
	else{
		var f=document.createElement('script');
		f.innerHTML='$.dialog.alert("<style>.dialogJ.dialogJfix{font-size:14px;color:#000;background:rgba(255,255,255,.5)!important;font-family:微软雅黑!important}.dialogJbody{padding:15px;word-break:initial;text-align:justify}</style>'+text+'",{title:"TieBa-Background Update notification",width:500})';
		document.body.appendChild(f);
		document.body.removeChild(f);
	}
}

function update_nextstep(){
	node.innerHTML='<p>下载已经开始或已打开下载链接，请耐心等待……</p><p>下载完成后请手动将文件解压并覆盖至 TieBa-Background 所在文件夹，然后点击此处的 <a class="tbbg_reload_ext">重新载入扩展程序</a></p><p>如果无法正常下载，请 <a class="tbbg_replay_response">选择其他下载地址</p></p>';
	document.getElementsByClassName('tbbg_reload_ext')[0].onclick=function(){chrome.runtime.reload()}
	document.getElementsByClassName('tbbg_replay_response')[0].onclick=function(){update_confirm()}
	window.resizeTo(500,220);
	window.moveTo(9999,9999);
}

if(window.location.hash.indexOf('first_run')>=0){
	node=document.querySelector('article');
	node.removeAttribute('align');
	node.innerHTML='感谢您使用 TieBa-Background，此弹窗为 TieBa-Background 的更新页面。当该窗口弹出时，请勿关闭该页面。当扩展程序完成检查更新后，若无更新，其会自动关闭；若有更新，则会提醒您下载更新。<br>如果您已了解，现在您可以关闭该页面了。';
	window.resizeTo(500,250);
	window.moveTo(9999,9999);
}
else{
	update_check();
}
