﻿// TieBa-Background 1.3.1
// Copyright (c) 2013-2014, 864907600cc. Some rights reserved.
// Released under the GPL license  http://www.gnu.org/licenses/gpl.html

console.log('%cTieBa-Background%c add setting listener function start.\nSend feedback? http://msg.baidu.com/msg/writing?receiver=864907600cc','color:#ff7f3e;text-decoration:underline','color:#ff7f3e');
var t0=new Date().getTime(),
	i,j,id,imgnum,imgstyle,imgx,imgy,imga,imga1,topa,css,setting,updatef,
	tbbg_image_ext='data:text/html;base64,77u/PGh0bWw+DQo8aGVhZD4NCjx0aXRsZT5UaWVCYS1CYWNrZ3JvdW5kIOWbvueJh+aJmOeuoeaJqeWxleeoi+W6j+mFjee9ruivtOaYjjwvdGl0bGU+DQo8c3R5bGU+YSxhOmhvdmVyLGE6dmlzaXRlZHtjb2xvcjojMDlGfTwvc3R5bGU+DQo8L2hlYWQ+DQo8Ym9keSBtYXJnaW5oZWlnaHQ9IjI1IiBtYXJnaW53aWR0aD0iMTAwIj4NCjxoMT5UaWVCYS1CYWNrZ3JvdW5kIOWbvueJh+aJmOeuoeaJqeWxleeoi+W6j+mFjee9ruivtOaYjjwvaDE+DQo8aHI+DQo8cD7mhJ/osKLmgqjkvb/nlKggVGllQmEtQmFja2dyb3VuZOOAguaOpeS4i+adpeeahOatpemqpOWwhuW8leWvvOS9oOWuieijheWbvueJh+aJmOeuoeaJqeWxleeoi+W6j+OAgjwvcD4NCjxvbD4NCgk8bGk+6K+35bCG5omA5pyJ55qE5Zu+54mH5paH5Lu25LulIDEuanBn44CBMi5qcGfjgIEzLmpwZ+OAgTQuanBn44CBNS5qcGcg4oCm4oCm6L+Z5qC355qE5paH5Lu25ZCN5ZG95ZCN77yI5ZCO57yA5b+F6aG75pivIC5qcGfvvIzmlofku7blkI3lv4XpobvmmK/nlLEgMSDlvIDlp4vnmoTov57nu63mlbDlrZfvvInvvIzmlL7lnKjkuIDkuKrkuI3kvJrooqvnp7vpmaTnmoTmlofku7blpLnlhoU8YnI+DQoJICA8c3Ryb25nIHN0eWxlPSJjb2xvcjpyZWQiPuazqOaEj++8muivt+S4jeimgeWwhuaWh+S7tuWQjeWGmeaIkCAxLmpwZy5qcGfvvIwyLmpwZy5qcGfvvIwzLmpwZy5qcGfvvIw0LmpwZy5qcGcg4oCm4oCm55qE5b2i5byP77yBV2luZG93cyDmk43kvZzns7vnu5/or7flnKjmlofku7blpLnpgInpobnnmoQmbGRxdW875p+l55yLJnJkcXVvO+mAiemhueWNoeS4reWPlua2iOWLvumAiSZsZHF1bzvpmpDol4/lt7Lnn6Xmlofku7bnsbvlnovnmoTmianlsZXlkI0mcmRxdW875Lul56Gu6K6k5paH5Lu25ZCN5piv5ZCm5q2j56GuPC9zdHJvbmc+CSAgPGJyPg0KCTwvbGk+DQoJPGxpPjxhIGhyZWY9ImRhdGE6dGV4dC9wbGFpbjtiYXNlNjQsNzd1L2V3MEtDU0ozWldKZllXTmpaWE56YVdKc1pWOXlaWE52ZFhKalpYTWlPaUJiSUNJcUlpQmRMQTBLQ1NKdVlXMWxJam9nSWxScFpVSmhMVUpoWTJ0bmNtOTFibVFnNVp1KzU0bUg1b21ZNTY2aDVvbXA1YkdWNTZpTDVicVBJaXdOQ2draVpHVnpZM0pwY0hScGIyNGlPaUFpNXB5czVvbXA1YkdWNTZpTDVicVA1NVNvNUxxTzZMMjk1WVdsSUZScFpVSmhMVUpoWTJ0bmNtOTFibVFnNTVxRTZJT001cG12NVp1KzU0bUg3N3lNNVlXMzVMMlQ1TDIvNTVTbzVwYTU1ck9WNksrMzVZK0M2S2VCSUZScFpVSmhMVUpoWTJ0bmNtOTFibVFnNTVxRTZLNis1NzJ1NmFHMTQ0Q0NJaXdOQ2draWRtVnljMmx2YmlJNklDSXhJaXdOQ2draWJXRnVhV1psYzNSZmRtVnljMmx2YmlJNklESU5DbjA9IiBkb3dubG9hZD0ibWFuaWZlc3QuanNvbiI+6K+354K55Ye75LiL6L296L+Z5LiqIG1hbmlmZXN0Lmpzb24g5paH5Lu2PC9hPjwvbGk+DQoJPGxpPuWwhuivpSBtYW5pZmVzdC5qc29uIOaWh+S7tuenu+WKqOiHs+iDjOaZr+WbvueJh+aJgOWcqOeahOaWh+S7tuWkueWGhTwvbGk+DQoJPGxpPuWcqCBjaHJvbWUg5Zyw5Z2A5qCP5Lit6L6T5YWlIGNocm9tZTovL2V4dGVuc2lvbnMg5bm25Zue6L2m77yM5Zyo5omp5bGV56iL5bqP6aG15Yu+6YCJ5Y+z5LiK6KeS55qE4oCc5byA5Y+R6ICF5qih5byP4oCdPC9saT4NCgk8bGk+54K55Ye76aG16Z2i5LiK5pa555qE4oCc5Yqg6L295q2j5Zyo5byA5Y+R55qE5omp5bGV56iL5bqPLi4u4oCd5oyJ6ZKu77yM5Zyo55uu5b2V5qCR5Lit5om+5Yiw6K+l5Zu+54mH55qE5paH5Lu25aS577yM54K55Ye756Gu5a6aPC9saT4NCgk8bGk+5aaC5p6c5LiA5YiH5q2j5bi477yM5omp5bGV56iL5bqP5bCG5a6J6KOF5oiQ5Yqf77yM6K+35Zyo5LiL6Z2i55qE5omp5bGV56iL5bqP5YiX6KGo5Lit5om+5Yiw4oCcVGllQmEtQmFja2dyb3VuZCDlm77niYfmiZjnrqHmianlsZXnqIvluo/igJ3vvIzlsIblhbblkI7nmoQgMzIg5L2NIElEIOWkjeWItuS4i+adpeWkh+eUqDwvbGk+DQoJPGxpPuWwhuW+l+WIsOeahCBJRCDotLTlhaUgVGllQmEtQmFja2dyb3VuZCDorr7nva7pobXkuK3nmoTmjIflrprkvY3nva7vvIzngrnlh7vigJzkv53lrZjigJ0gPC9saT4NCjwvb2w+DQo8cD7oh7PmraTvvIxUaWVCYS1CYWNrZ3JvdW5kIOWbvueJh+aJmOeuoeaJqeWxleeoi+W6j+W3sumFjee9ruWujOaIkOOAgjwvcD4NCjxwPuWmguaenOaCqOaJvuS4jeWIsOiuvue9rumhte+8jOivt+Wwhum8oOagh+enu+iHs+i0tOWQp+mhtemdoumhtuerr+WPs+S4iuinkueahCBJRCDlpITvvIzlnKjkuIvmi4nliJfooajkuK3ngrnlh7vigJzog4zmma/orr7nva7igJ3vvJvmiJbogIXorr/pl67mgqjnmoQgaSDotLTlkKfvvIzngrnlh7vnlYzpnaLlj7PkvqfnmoTigJzog4zmma/orr7nva7igJ3jgII8L3A+DQo8cD7or7fms6jmhI/vvIzor7fkuI3opoHnp7vliqjjgIHliKDpmaQgbWFuaWZlc3QuanNvbiDmlofku7blkozor6Xmlofku7blpLnjgILlpoLmnpzmgqjnp7vliqjjgIHliKDpmaTkuobor6Xmlofku7bmiJbmlofku7blpLnvvIwg6ZyA6YeN5paw5omn6KGM5Lul5LiK5q2l6aqk44CCPC9wPg0KPHA+PGEgc3R5bGU9J2NvbG9yOiNjMzMnIGhyZWY9J2h0dHA6Ly9leHQuY2Nsb2xpLmNvbS90aWViYS1iYWNrZ3JvdW5kL2hlbHAvJyB0YXJnZXQ9J19ibGFuayc+5aaC5p6c5oKo5LuN5LiN55+l6YGT5oCO5LmI5pON5L2c77yM6K+354K55Ye75q2k5aSE5p+l55yL6KeG6aKR5pWZ56iL44CCPC9hPjwvcD4NCjxwPjxzbWFsbD7mhJ/osKIgPGEgaHJlZj0iaHR0cDovL3d3dy5iYWlkdS5jb20vcC9FbmRsZXNzTG92ZTEyMiIgdGFyZ2V0PSJfYmxhbmsiPkBFbmRsZXNzTG92ZTEyMjwvYT4g5pu+57uP5o+Q5L6b55qE6K6/6Zeu5pys5Zyw5paH5Lu255qE5pa55rOV77yM6Jm954S255Sx5LqO6LWE5rqQ5Y2g55So6L+H5aSn6KKr6L+r5pS+5byD5LqG4oCm4oCmPC9zbWFsbD48L3A+DQo8L2JvZHk+DQo8L2h0bWw+';
if(!window.localStorage.getItem('tbbg_setting'))var tbbg_value=new Object();
else var tbbg_value=JSON.parse(window.localStorage.getItem('tbbg_setting'));

if(!tbbg_value.id)tbbg_value.id='';
if(!tbbg_value.imgnum)tbbg_value.imgnum='1';
if(!tbbg_value.imgstyle)tbbg_value.imgstyle='cover';
if(!tbbg_value.imgx)tbbg_value.imgx='center';
if(!tbbg_value.imgy)tbbg_value.imgy='center';
if(!tbbg_value.imga)tbbg_value.imga='50';
if(!tbbg_value.topa)tbbg_value.topa='true';
if(!tbbg_value.updatef){
	tbbg_first_install_request();
	tbbg_value.updatef='1';
}
if(!tbbg_value.css)tbbg_value.css='*{font-family:微软雅黑}';
if(tbbg_value.imgchg){
	tbbg_value.imga='50';
	tbbg_value.css='*{font-family:微软雅黑}';
	tbbg_stop_support();
}


window.addEventListener('load',function(){
	var u=document.getElementsByClassName('u_tb_profile')[0]||document.getElementsByClassName('u_school')[0];
	if(u){
		var c=document.createElement('li'),d=document.createElement('a');
		c.className='u_tbbg_setting';
		c.style.cursor='pointer';
		d.innerHTML='背景设置';
		//d.href='#!tbbg_setting';
		u.parentElement.insertBefore(c,u.nextElementSibling);
		c.appendChild(d);
		c.onclick=function(event){tbbg_setting_function();};
	}
},false)
/*if(window.location.hash=='#!tbbg_setting'){
	tbbg_setting_function();
}*/
function tbbg_setting_function(){
	var t=new Date().getTime(),
		bg=document.getElementsByClassName('TBBG_background')[0];
	var tbbg_setting_container=document.createElement('div'),
		tbbg_setting_outer=document.createElement('div');
	tbbg_setting_container.id='tbbg_setting_container';
	tbbg_setting_outer.id='tbbg_setting_outer';
	tbbg_setting_container.style.cssText='width:750px;position:absolute;left:-webkit-calc((100% - 750px)/2);top:50px;background:rgba(255,255,255,.5);box-shadow:0 0 5px rgba(0,0,0,.3);border-radius:3px;box-shadow:0 0 0 99999px rgba(0,0,0,.4);z-index:39999';
	tbbg_setting_outer.style.cssText='width:100%;height:100%;position:fixed;left:0;top:0;z-index:39998';
	document.body.appendChild(tbbg_setting_container);
	document.body.appendChild(tbbg_setting_outer);
	tbbg_setting_container.innerHTML='<div class="tbbg_setting" style="width:700px;margin:25px"><style>@font-face{font-family:"tbbg_font";unicode-range:U+2E80-FFFF;src:local("Microsoft Yahei"),local("微软雅黑"),local("微軟細黑")}@font-face{font-family:"tbbg_font";unicode-range:U+0000-2E7F;src:local("Segoe Print"),local("Arial")}.tbbg_setting *{font-family:tbbg_font!important;color:#000}.tbbg_setting h1{font-family:"Segoe Script",tbbg_font!important;color:#FFA533;text-shadow:0 0 2px #FFA533}.tbbg_setting input,.tbbg_setting textarea{border:1px dashed #999!important;background-color:rgba(255,255,255,.3);margin:0;padding:0}.tbbg_setting input{height:20px}.tbbg_setting label{padding-right:15px}.tbbg_setting td{font-size:14px!important}.tbbg_setting #tbbg_submit{background-image:url(http://tb2.bdstatic.com/tb/static-common/editor_img/btn_submit_post_69622fa8.gif?t=20121216);width:100px;height:40px;background-size:100%;color:white;font-size:16px;line-height:40px;cursor:pointer;margin:15px}.tbbg_setting #tbbg_submit:hover{background-position:0 -40px}.tbbg_setting #tbbg_submit:active{background-position: 0 -80px}.tbbg_setting h1{font-size:2em}.tbbg_setting a,.tbbg_setting a:visited{color:#09F!important;cursor:pointer}</style><h1 align="center" style="line-height:60px;line-height:40px">TieBa-Background Setting</h1><hr style="border: 1px #FFA533 dashed;margin-bottom:15px"><table width="700"><tbody align="justify" valign="middle"><tr height="32"><td width="120" title="在此处输入您安装的“TieBa-Background 背景托管扩展程序”的 32 位 ID&#13;若您不知道如何填写或位未安装，请点击右侧的“如何填写？”&#13;* 请务必填写正确，否则将无法正常显示背景图片&#13;* 这个 ID 不是 TieBa-Background 的 ID">托管扩展程序 ID</td><td><input type="text" id="tbbg_1" style="width:500px" name="tbbg_id"><small style="padding-left:5px"><a href="'+tbbg_image_ext+'" target="_blank">如何填写？</a></small></td></tr><tr height="32"><td width="120" title="在此处输入图片数目&#13;* 请以 1.jpg , 2.jpg , 3.jpg , 4.jpg ...的形式命名文件">背景图片数量</td><td><input type="number" id="tbbg_2" style="width:75px;text-align:right" name="tbbg_imgnum" min="1"></td></tr><tr height="32"><td width="120" title="设置背景图片的显示方式（单击选项可预览）">背景样式</td><td><input name="tbbg_imgstyle" type="radio" id="tbbg_31" value="auto"><label for="tbbg_31">无</label><input name="tbbg_imgstyle" type="radio" id="tbbg_32" value="cover"><label for="tbbg_32">填充</label><input name="tbbg_imgstyle" type="radio" id="tbbg_33" value="contain"><label for="tbbg_33">适应</label><input name="tbbg_imgstyle" type="radio" id="tbbg_34" value="100% 100%"><label for="tbbg_34">拉伸</label><input name="tbbg_imgstyle" type="radio" id="tbbg_35" value="repeat"><label for="tbbg_35">平铺</label></td></tr><tr height="32"><td width="120" title="设置背景图片的水平位置（单击选项可预览）">背景水平位置</td><td><input name="tbbg_imgx" type="radio" id="tbbg_41" value="left"><label for="tbbg_41">居左</label><input name="tbbg_imgx" type="radio" id="tbbg_42" value="center"><label for="tbbg_42">居中</label><input name="tbbg_imgx" type="radio" id="tbbg_43" value="right"><label for="tbbg_43">居右</label></td></tr><tr height="32"><td width="120"  title="设置背景图片的垂直位置（单击选项可预览）">背景垂直位置</td><td><input name="tbbg_imgy" type="radio" id="tbbg_51" value="top"><label for="tbbg_51">靠上</label><input name="tbbg_imgy" type="radio" id="tbbg_52" value="center"><label for="tbbg_52">居中</label><input name="tbbg_imgy" type="radio" id="tbbg_53" value="bottom"><label for="tbbg_53">靠下</label></td></tr><tr height="32"><td width="120" title="设置背景图片的透明度（滑动滑块可预览）">背景透明度</td><td><input type="range" id="tbbg_6" style="width:500px;" name="tbbg_imga" min="0" max="100"><span id="tbbg_61" style="padding-left:5px"></span>%</td></tr><tr height="32"><td width="120" title="设置是否显示顶部的白色遮罩层（单击选项可预览）">顶部遮罩层</td><td><input name="tbbg_topa" type="radio" id="tbbg_71" value="true"><label for="tbbg_71">开启</label><input name="tbbg_topa" type="radio" id="tbbg_72" value="false"><label for="tbbg_72">关闭</label></td></tr><tr height="32"><td width="120" title="选择检查更新的方式，默认为弹窗检查更新">检查更新方式</td><td><input name="tbbg_updatef" type="radio" id="tbbg_d1" value="1"><label for="tbbg_d1">弹窗检查更新</label><input name="tbbg_updatef" type="radio" id="tbbg_d2" value="2"><label for="tbbg_d2">静默检查更新</label><input name="tbbg_updatef" type="radio" id="tbbg_d3" value="0"><label for="tbbg_d3">不检查更新</label> <span style="cursor:pointer;color:#00F" onclick="window.open(\''+chrome.runtime.getURL('update.html')+'\',\'tbbg_update\',\'width=500,height=150,left=9999,top=9999\');">手动检查更新</span></td></tr><tr><td width="120" height="32" title="在此设置您的自定义 css 样式&#13;* 请在保存前确认 css 语法正确">自定义样式</td><td rowspan="2"><textarea name="tbbg_css" id="tbbg_b" style="width:570px;max-width:570px;height:60px"></textarea></td></tr><tr></tr><tr height="40"><td colspan="2"><center><div id="tbbg_submit">保存设置</div></center></td></tr><tr height="32"><td colspan="2"><center><div id="tbbg_load"></div></center></td></tr><tr height="20"><td colspan="2"><center><small style="word-spacing:25px"><a id="tbbg_reset">重置扩展</a> <a id="tbbg_backup">备份设置</a> <a id="tbbg_recover">恢复设置</a> <a id="tbbg_feedback">反馈</a> <a id="tbbg_about">关于</a> <a id="tbbg_thanks">致谢</a></small></center></td></tbody></table></div>';
	setting=document.getElementsByClassName('tbbg_setting')[0],
	id=document.getElementsByName('tbbg_id')[0],
	imgnum=document.getElementsByName('tbbg_imgnum')[0],
	imgstyle=document.getElementsByName('tbbg_imgstyle'),
	imgx=document.getElementsByName('tbbg_imgx'),
	imgy=document.getElementsByName('tbbg_imgy'),
	imga=document.getElementsByName('tbbg_imga')[0],
	imga1=document.getElementById('tbbg_61'),
	topa=document.getElementsByName('tbbg_topa'),
	css=document.getElementsByName('tbbg_css')[0],
	updatef=document.getElementsByName('tbbg_updatef'),
	id.value=tbbg_value.id,
	imgnum.value=tbbg_value.imgnum;
	for(i=0,j=imgstyle;i<j.length;i++) {
		if(j[i].value==tbbg_value.imgstyle){
			j[i].setAttribute('checked','checked');
			break;
		}
	}
	for(i=0,j=imgx;i<j.length;i++) {
		if(j[i].value==tbbg_value.imgx){
			j[i].setAttribute('checked','checked');
			break;
		}
	}
	for(i=0,j=imgy;i<j.length;i++) {
		if(tbbg_value.imgy==j[i].value){
			j[i].setAttribute('checked','checked');
			break;
		}
	}
	imga.value=tbbg_value.imga;
	for(i=0,j=topa;i<j.length;i++) {
		if(tbbg_value.topa==j[i].value){
			j[i].setAttribute('checked','checked');
			break;
		}
	}
	css.value=tbbg_value.css;
	imga1.innerHTML=tbbg_value.imga;
	imga.onchange=function(event){
		imga1.innerHTML=this.value;
		bg.style.opacity=(100-this.value)/100;
	}
	if(tbbg_value.updatef){
		for(i=0,j=updatef;i<j.length;i++) {
			if(tbbg_value.updatef==j[i].value){
				j[i].setAttribute('checked','checked');
				break;
			}
		}
	}
	for(i=0,j=document.getElementsByTagName('input');i<j.length;i++) {
		if(j[i].hasAttribute('type','radio')){
			j[i].onclick=tbbg_preview;
		}
	}
	document.getElementById('tbbg_submit').onclick=function(event){tbbg_save()};
	if(document.getElementById('tbbg_setting_outer'))tbbg_setting_outer.onclick=function(event){
		tbbg_setting_container.outerHTML='';
		tbbg_setting_outer.outerHTML='';
		window.location.hash='';
	};
	tbbg_bottom();
	document.getElementById('tbbg_load').innerHTML='页面生成耗时: '+(new Date().getTime()-t)+'ms';
}
function tbbg_preview(){
	if(this.name=='tbbg_imgstyle'){
		if(this.value=='repeat'){
			bg.style.backgroundSize='auto';
			bg.style.backgroundRepeat='repeat';
		}
		else{
			bg.style.backgroundSize=this.value;
			bg.style.backgroundRepeat='no-repeat';
		}
	}
	else if(this.name=='tbbg_imgx')bg.style.backgroundPositionX=this.value;
	else if(this.name=='tbbg_imgy')bg.style.backgroundPositionY=this.value;
	else if(this.name=='tbbg_topa'){
		if(this.value=='true')document.getElementsByClassName('TBBG_top_white')[0].style.display="block";
		else document.getElementsByClassName('TBBG_top_white')[0].style.display="none";
	}
}

function tbbg_save(){
	var tbbg_setting=new Object();
	if(/[a-p]{32}/gi.test(id.value))tbbg_setting.id=id.value.match(/[a-p]{32}/gi)[0];
	else{alert('您的扩展程序 ID 格式不正确，请重新核实......');return}
	tbbg_setting.imgnum=imgnum.value;
	for (i=0,j=imgstyle;i<j.length;i++) {
		if(j[i].checked){
			tbbg_setting.imgstyle=j[i].value;
			break;
		}
	}
	for (i=0,j=imgx;i<j.length;i++) {
		if(j[i].checked){
			tbbg_setting.imgx=j[i].value;
			break;
		}
	}
	for (i=0,j=imgy;i<j.length;i++) {
		if(j[i].checked){
			tbbg_setting.imgy=j[i].value;
			break;
		}
	}
	tbbg_setting.imga=imga.value;
	for (i=0,j=topa;i<j.length;i++) {
		if(j[i].checked){
			tbbg_setting.topa=j[i].value;
			break;
		}
	}
	for(i=0,j=updatef;i<j.length;i++) {
		if(j[i].checked){
			tbbg_setting.updatef=j[i].value;
			break;
		}
	}
	tbbg_setting.css=css.value;
	window.localStorage.setItem('tbbg_setting',JSON.stringify(tbbg_setting));
	alert('保存完毕~~~请刷新页面~~~>▽<');
	if(document.getElementById('tbbg_setting_container')){
		tbbg_setting_container.outerHTML='';
		tbbg_setting_outer.outerHTML='';
		window.location.hash='';
	}
}

function tbbg_update(){
	if(tbbg_value.updatef=='1'){
		window.open(chrome.runtime.getURL('update.html'),'tbbg_update','width=500,height=150,left=9999,top=9999');
		window.localStorage.setItem('tbbg_update',new Date().getDate());
	}
	else if(tbbg_value.updatef=='2'){
		var s=document.createElement('script'),
			f=document.createElement('script'),
			c=document.createElement('style');
		s.innerHTML='var tbbg_version="'+chrome.runtime.getManifest().version+'";';
		document.head.appendChild(s);
		c.innerHTML='.tbbg_update_notification{font-size:14px;margin:auto;width:500px;left:0;right:0;top:0;bottom:0;position:fixed;z-index:99999;background:rgba(255,255,255,.75);box-shadow:0 0 0 10000px rgba(0,0,0,.5);font-size:14px!important;padding:15px}.tbbg_update_notification h1{font-size:16px}.tbbg_update_notification ol,.tbbg_update_notification ul{margin:0}.tbbg_update_notification ul{padding:0}.tbbg_update_notification ol{display:block;list-style-type:decimal;margin:0 1em;padding-left:24px}.tbbg_update_notification ul li{display:inline-block;margin-left:16px}.tbbg_update_notification p{margin:5px 0}.tbbg_update_notification a{color:#39F;text-decoration:none;cursor:pointer}.tbbg_update_notification div{margin-left:25px;border-left:#F3C solid 2px}';
		document.head.appendChild(c);
		f.src=chrome.runtime.getURL('update.js');
		f.charset="UTF-8"
		document.body.appendChild(f);
		//window.localStorage.setItem('tbbg_update',new Date().getDate());
	}
}

function tbbg_first_install_request(){
	var c=document.createElement('div');
	c.style.cssText='font-size:14px;color:#000;background:rgba(255,255,255,.9);position:fixed;left:0px;right:0px;top:0px;bottom:0px;margin:auto;overflow:auto;padding:50px;z-index:999999';
	c.innerHTML='<h2>TieBa-Background 安装确认</h2><hr><p>您即将完成安装 TieBa-Background，在继续安装前，我们需要让您知晓一些注意事项和扩展程序权限。</p><div style="border-left:#0069D6 2px;padding:15px"><h3>警告</h3><ol><li>请色盲、弱视用户等有阅读困难的用户停止安装，因为该扩展可能会造成阅读障碍。</li><ol></div><div style="border-left:#0069D6 2px;padding:15px"><h3>注意</h3><ol><li>本扩展程序可能会给您造成阅读困难，建议您使用色调偏亮的图片并调节背景透明度。</li><li>本扩展程序将消耗较多的 CPU 资源，例如在载入图片时。</li><li>本扩展程序将消耗较多的内存以储存图片，这部分内存会随标签页归属进程的结束而释放。</li><li>本扩展程序将可能导致浏览页面不流畅、响应较慢等问题，这是由于程序架构未做到很好的优化和 Google Chrome 自身渲染含有较多 bug。</li><li>由于 Chrome 的渲染问题，为尽可能减少渲染时间，建议不要使用过大的图片。</li><li>由于 Chrome 的渲染问题，建议您关闭自动切换图片功能（新安装用户默认关闭；该功能在 Chrome 28 及以上版本支持度不佳）。</li><ol></div><div style="border-left:#0069D6 2px;padding:15px"><h3>权限说明</h3>这是一份简略文件，具体权限使用可参考<a href="http://ext.ccloli.com/tieba-background/permission/" target="_blank">此处</a>。<ol><li>本扩展程序将有权访问 tieba.baidu.com 下大部分页面以修改页面。</li><li>本扩展程序将有权访问 ext.ccloli.com、chrome.afraid.xxx 等服务器以获取更新。</li><ol></div><p>是否继续？</p><p align="center"><span class="tbbg-first-install-true" style="cursor:pointer;color:#00F">是，继续安装</span>　　<span class="tbbg-first-install-false" style="cursor:pointer;color:#00F">不，取消安装</span></p>';
	document.body.appendChild(c);
	c.getElementsByClassName('tbbg-first-install-true')[0].onclick=function(){
		document.body.removeChild(c);
		tbbg_first_install();
	}
	c.getElementsByClassName('tbbg-first-install-false')[0].onclick=function(){
		alert('您已取消安装，请在扩展程序页删除本扩展程序，然后删除扩展程序文件夹即可。');
		document.body.removeChild(c);
	}
}

function tbbg_first_install(){
	tbbg_value.updatef='1';
	var f=document.createElement('script');
	f.innerHTML='$.dialog.alert("<style>.dialogJ.dialogJfix{font-size:14px;color:#000;background:rgba(255,255,255,.5)!important;font-family:微软雅黑!important}.dialogJbody{padding:15px;word-break:initial;text-align:justify;height:430px!important}</style>欢迎您使用 TieBa-Background ζ*\'ヮ\')ζ<br><br>基于 Google Chrome 的安全设定，我们更改了扩展程序的安装方式。如果您之前使用过 TieBa-Background 1.2 的话，那么您应该对此过程非常熟悉。在最后我们会对更新方式进行具体说明，请耐心阅读。<br><br>“怎么没有背景图片了呢？”<br>是的，为了节省下载更新的时间和带宽，从 TieBa-Background 1.3 起将不会自带背景图片，但是同以往的版本一样，您可以使用自定义的本地图片，只不过初次使用时要进行比较麻烦的设置，稍后我们会谈到。<br><br>“那么应该怎么设置背景图片呢？”<br>首先，您需要<a href=\''+tbbg_image_ext+'\' target=\'_blank\'>安装 TieBa-Background 图片托管扩展程序</a>，按照链接里的介绍完成该扩展程序的安装——嗯，和以往的 TieBa-Background 安装方法一样，应该很熟悉吧 0w0 ——然后取得扩展程序的 32 位 ID，填写至本弹窗后面的设置界面上的相应位置，输入图片数目，保存即可。<br><br>“设置界面上的各个设置项有什么用途呢？”<br>关于各个设置项的具体含义，可以将鼠标移到设置界面左侧的设置项名称上，悬停一会就会显示它的具体含义了；另外部分设置项可以提供预览，您可以单击相应的选项实时查看效果，很方便吧~~~<del>不过实现好麻烦 TUT</del><br><br>“现在我将如何更新扩展程序呢？”<br>为绕过 Google Chrome 的安全限制，我们更改了扩展程序的更新方式。在每天第一次打开贴吧时，扩展程序将弹出窗口检查更新（<del>可在设置页使用静默更新</del>因浏览器及网站安全设置，该功能暂未实现，在此致歉），如果有更新时我们会提醒您安装。您只需要将更新的压缩包下载下来，解压至 TieBa-Background 扩展程序根目录，覆盖同名文件即可。<br><br>嗯，安装向导到此就结束了，稍候您还需要完成扩展程序的相关设置，<b>请不要关闭本标签页</b>。现在就点击“确定”并完成相关设置吧~~> <",{title:"欢迎使用 TieBa-Background",width:1000})';
	document.body.appendChild(f);
	document.body.removeChild(f);
	window.open(chrome.runtime.getURL('update.html#first_run'),'tbbg_update','width=500,height=150,left=9999,top=9999');
	tbbg_setting_function();
}

function tbbg_bottom(){
	document.getElementById('tbbg_backup').onclick=function(event){prompt('请按下 Ctrl + C 复制文本并将保存至安全的地方...',window.localStorage.getItem('tbbg_setting'))}
	document.getElementById('tbbg_recover').onclick=function(event){
		var input=prompt('请将备份的文本粘贴至此处...');
		if(input!=null){
			window.localStorage.setItem('tbbg_setting',input);
			alert('设置数据已恢复，请刷新页面...');
		}
	}
	document.getElementById('tbbg_feedback').onclick=function(event){window.open('http://msg.baidu.com/msg/writing?receiver=864907600cc')}
	document.getElementById('tbbg_about').onclick=function(event){
		var f=document.createElement('script');
		f.innerHTML='$.dialog.alert("<style>.dialogJ.dialogJfix{font-size:14px;color:#000;background:rgba(255,255,255,.5)!important;font-family:微软雅黑!important}.dialogJbody{padding:15px;word-break:initial;text-align:justify}</style><b>TieBa-Background</b><br><br>为贴吧添加自定义背景，让贴吧不再单调。附带去除贴吧广告功能=，=<br><br>作者：864907600cc<br><!--<del>项目主页：<a href=\'http://tieba-background.ml\' target=\'_blank\'>http://tieba-background.ml</del></a> 已被喜闻乐见_(:з」∠)_-->",{title:"关于 TieBa-Background",width:600})';
		document.body.appendChild(f);
		document.body.removeChild(f);
	}
	document.getElementById('tbbg_reset').onclick=function(event){
		if(confirm('您即将重置 TieBa-Background，该操作将使扩展程序清除所有设置以恢复初始状态。如果您因初次安装配置不当而造成无法使用，或需要卸载本扩展程序而清除数据残留，可通过此功能重置扩展。\n注意：该操作是不可逆的。\n是否继续？')==true){
			localStorage.removeItem('tbbg_setting');
			alert('清除完毕......');
		}
	}
	document.getElementById('tbbg_thanks').onclick=function(event){
		var f=document.createElement('script');
		f.innerHTML='$.dialog.alert("<style>.dialogJ.dialogJfix{font-size:14px;color:#000;background:rgba(255,255,255,.5)!important;font-family:微软雅黑!important}.dialogJbody{padding:15px;word-break:initial;text-align:justify}</style>感谢这些朋友的友情帮助，没有你们就没有今天的 TieBa-Background<br>（抱歉咱记性不好……如果有缺漏啥的请私信 OTL）<br><br>为了活着 ( TieBa-Background 原作者)<br>5B4B铅笔 &nbsp;&nbsp;&nbsp;&nbsp;8qwe24657913 &nbsp;&nbsp;&nbsp;&nbsp;寒云似雾<br>EndlessLove122 &nbsp;&nbsp;&nbsp;&nbsp;我知道你明白 &nbsp;&nbsp;&nbsp;&nbsp;心中无码五道杠<br>反馈 bug 的朋友们<br>推广 TieBa-Background 的朋友们<br>以及正在使用 TieBa-Background 的您……",{title:"致谢",width:600})';
		document.body.appendChild(f);
		document.body.removeChild(f);
	}
}
function tbbg_stop_support(){
	var div=document.createElement('div'),
		div2=document.createElement('div');
	div.style.cssText='background:rgba(255,255,255,0.5);box-shadow:0 0 0 10000px rgba(0,0,0,0.5);border-radius:2px;padding:20px;width:600px;position:absolute;top:0;bottom:0;left:0;right:0;z-index:99999;margin:auto;padding:25px;font-size:14px';
	div2.title='点击黑色区域以退出';
	div2.style.cssText='width:100%;height:100%;top:0;bottom:0;left:0;right:0;margin:0;position:fixed;z-index:99998';
	div.innerHTML='<p align="center"><strong>TieBa-Background 暂停维护通知</strong></p><p>TieBa-Background 项目将在 2014 年 2 月 28 日至 2014 年 6 月 8 日暂停维护，预计于 2014 年 6 月 9 日后恢复维护。期间如果因贴吧修改而导致扩展程序显示异常或无法正常使用，本扩展可能亦不会更新。给您带来不便，还望多多包涵。</p><p>如果您了解 css 的编写和页面设计，且有意提供维护，请在贴吧 @864907600cc 或私信，或发送电子邮件至 h@cc.my-loli.com。</p><p>另外，本扩展已支持静默检查更新（但仍需要手动更新）。而由于 Chrome 的 GPU 加速功能仍旧存在 bug，扩展程序删除了图片预加载的功能，并对页面进行了一些调整，在此致歉。</p><p>最后，请重新保存设置以保证该提醒不再出现。</p>';
	document.body.appendChild(div);
	document.body.appendChild(div2);
	div2.addEventListener('click',function(){
		div.parentElement.removeChild(div);
		div2.parentElement.removeChild(div2);
	})
	tbbg_setting_function()
}

if(window.localStorage.getItem('tbbg_update')!=new Date().getDate()&&tbbg_value.updatef!='0')tbbg_update();

console.log('%cTieBa-Background%c 监听设置事件程序载入时间统计：'+(new Date().getTime()-t0)+'ms','color:#4a82f0;text-decoration:underline','color:#4a82f0');