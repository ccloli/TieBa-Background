// TieBa-Background 1.3.1
// Copyright (c) 2013-2014, 864907600cc. Some rights reserved.
// Released under the GPL license  http://www.gnu.org/licenses/gpl.html

var popup,
	response,
	node,
	server=parseInt(localStorage.tbbg_server)||0,
	serverlist=['http://ext.ccloli.com/tieba-background/update/','http://chrome.afraid.xxx/tieba-background/update/'],
	version;
if(location.protocol=='chrome-extension:'){
	popup=1;
	node=document.querySelector('article');
	version==chrome.runtime.getManifest().version;
}
else{
	popup=0;
	version=tbbg_version;
	node=document.createElement('div');
	node.className='tbbg_update_notification';
}

function update_check(){
	var xhr=new XMLHttpRequest();
	xhr.open('GET',serverlist[server]+'?version='+version);
	xhr.onreadystatechange=function(){
		if(xhr.readyState==4){
			if(xhr.status==200){
				if(popup==0)window.localStorage.setItem('tbbg_update',new Date().getDate());
				response=JSON.parse(xhr.responseText);
				if(response.need_update=='true'){
					update_confirm();
				}
				else{
					if(popup==1){
						node.innerHTML='TieBa-Background 暂无更新，正在关闭窗口……';
						setTimeout(function(){window.close();},1000);
					}
				}
			}
			else{
				if(server<serverlist.length-1){
					server++;
					if(popup==1)node.innerHTML='连接服务器出错，正在尝试访问其他更新服务器……';
					update_check();
				}
				else{
					if(popup==1){
						node.innerHTML='<span style="color:#F00">连接服务器出错，请检查您的网络设置后重新检查更新……</span>';
						setTimeout(function(){window.close();},5000);
					}
				}
			}
		}
	}
	xhr.send(); 
}

function update_confirm(){
	var jdetail='',
		jserver='',
		jdrive='',
		text;
	for(var i=0;i<response.update_detail.length;i++){
		jdetail+='<li>'+response.update_detail[i]+'</li>';
	}
	for(var i=0;i<response.update_server.length;i++){
		jserver+='<li><a href="'+response.update_server[i].url+'" download="tieba-background-update-'+response.version+'.zip">'+response.update_server[i].name+'</a></li>';
	}
	for(var i=0;i<response.update_webdrive.length;i++){
		jdrive+='<li><a href="'+response.update_webdrive[i].url+'" target="_blank">'+response.update_webdrive[i].name+'</a></li>';
	}
	text='<p align="center" style="color:#f00">TieBa-Background 已有最新更新……<p><p>版本号：'+response.version+'</p><p>更新详情：</p><div><ol>'+jdetail+'</ol></div><p>请点击下面的链接下载更新，下载后请将其解压至扩展程序所在目录并覆盖文件，然后刷新扩展程序页。</p><p>服务器下载链接：</p><div><ul>'+jserver+'</ul></div><p>备用网盘下载链接：</p><div><ul>'+jdrive+'</ul></div>';
	if(popup==1){
		node.removeAttribute('align');
		node.innerHTML=text;
		window.resizeTo(500,320+(response.update_detail.length*16));
		window.moveTo(9999,9999);
		var z=document.getElementsByTagName('a');
		for(var w=0;w<z.length;w++)z[w].onclick=function(){update_nextstep()};
	}
	else{
		if(typeof node2 == 'undefined'){
			node2=document.createElement('div');
			node2.style.cssText='left:0;top:0;width:100%;height:100%;z-index:99998;position:fixed;cursor:pointer';
			node2.title='点击黑色区域以关闭弹窗';
			document.body.appendChild(node2);
			document.body.appendChild(node);
			node2.onclick=function(){
				node2.remove();
				node.remove();
			}
		}
		node.innerHTML=text;
		var z=node.getElementsByTagName('a');
		for(var w=0;w<z.length;w++)z[w].onclick=function(){update_nextstep()};
		node.style.height=320+(response.update_detail.length*16)+'px';
	}
}

function update_nextstep(){
	node.innerHTML='<p>下载已经开始或已打开下载链接，请耐心等待……</p><p>下载完成后请手动将文件解压并覆盖至 TieBa-Background 所在文件夹，然后点击此处的 <a class="tbbg_reload_ext">重新载入扩展程序</a></p><p>如果无法正常下载，请 <a class="tbbg_replay_response">选择其他下载地址</p></p>';
	document.getElementsByClassName('tbbg_replay_response')[0].onclick=function(){update_confirm()}
	if(popup==1){
		document.getElementsByClassName('tbbg_reload_ext')[0].onclick=function(){chrome.runtime.reload()}
		window.resizeTo(500,220);
		window.moveTo(9999,9999);
		window.opener.localStorage.removeItem('tbbg_update');
	}
	else{
		node.style.height=220+'px';
		document.getElementsByClassName('tbbg_reload_ext')[0].onclick=function(){alert('当前环境不支持重新载入，请在扩展程序页（chrome://extensions）中按下 F5 或刷新按钮以更新。')}
	}
}

if(window.location.hash.indexOf('first_run')>=0){
	node=document.querySelector('article');
	node.removeAttribute('align');
	node.innerHTML='感谢您使用 TieBa-Background，此弹窗为 TieBa-Background 的更新页面。当该窗口弹出时，请勿关闭该页面。当扩展程序完成检查更新后，若无更新，其会自动关闭；若有更新，则会提醒您下载更新。<br>如果您已了解，现在您可以关闭该页面了。';
	window.resizeTo(500,250);
	window.moveTo(9999,9999);
}
else{
	update_check();
}
