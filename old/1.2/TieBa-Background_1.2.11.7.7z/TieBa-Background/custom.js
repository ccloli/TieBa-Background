﻿/*TieBa-Background JS文件*/
/*By 为了活着 & 864907600cc*/
/*Thanks To 5B4B铅笔 & 寒云似雾*/
/*2013-6-7 23:52:23*/

var img = 4 ;//图片张数（默认4张，设置为0即不开启图片背景）
var chgtime = 30 ;//背景切换时间（以秒计,默认30秒，时限不限，设置为0即不开启图片切换）
var update = 1 ;//自动检查更新（默认开启，设置0为不检查更新，1为自动检查更新）

//注意：开启自动更新后仅会在每日第一次访问贴吧时静默检查更新，其间会静默访问更新服务器获取更新。详情请浏览http://tieba.baidu.com/p/1813652160

/**若您不了解相关代码的含义，请勿修改以下代码**/
if(img>=1){function replaceBG(){if(document.body){document.removeEventListener('beforeload',replaceBG,true);var doc=document.body;doc.setAttribute('has_TBBG_extension','true');var bg=document.createElement('div');bg.className='TBBG_background';bg.setAttribute('extension-name','TieBa-Background');doc.appendChild(bg);var bg=document.getElementsByClassName('TBBG_background')[0];var num=parseInt(Math.random()*img+1);bg.style.cssText='background-image:-webkit-linear-gradient(rgba(255,255,255,.3),rgba(255,255,255,.3)),url('+chrome.extension.getURL(num+'.jpg')+')!important;background-size:cover!important;';bg.style.backgroundAttachment='fixed';bg.style.backgroundPosition='center center';bg.style.backgroundRepeat='no-repeat';seed=document.createElement('div');seed.className='TBBG_top_white';seed.setAttribute('extension-name','TieBa-Background');doc.appendChild(seed);setTimeout(function(){chg();},chgtime*500);function chg(){if(chgtime!="0"){var num=parseInt(Math.random()*img+1);if(!document.getElementById('TBBG_preload')){rel=document.createElement('div');rel.id='TBBG_preload';rel.setAttribute('extension-name','TieBa-Background');doc.appendChild(rel);}rel.style.cssText='background-image:url('+chrome.extension.getURL(num+'.jpg')+')!important;';setTimeout(function(){bg();},chgtime*500);function bg(){var bg=document.getElementsByClassName('TBBG_background')[0];bg.style.cssText='background-image:-webkit-linear-gradient(rgba(255,255,255,.3),rgba(255,255,255,.3)),url('+chrome.extension.getURL(num+'.jpg')+')!important;background-size:cover!important;';bg.style.backgroundAttachment='fixed';bg.style.backgroundPosition='center center';bg.style.backgroundRepeat='no-repeat';setTimeout(function(){chg();},chgtime*500);}}}}}(function(s){var x=document.createElement("style");x.textContent=s;x.type="text/css";x.id="TBBG_Stylesheet";x.setAttribute('extension-name','TieBa-Background');document.documentElement.appendChild(x);})(".wrap1,.wrap2,.thread_theme_4,body[class*=skin]{background:none!important}.tb-editor-wrapper{background-color:rgba(244,244,244,.3)!important}");document.addEventListener('beforeload',replaceBG,true)}
if(!window.localStorage.getItem('tbbg_welcome')){
	window.addEventListener('load',function(e){
		var s=document.createElement("script");
		s.src='http://ext.ccloli.com/tbbg/update2/welcome.php';
		document.body.appendChild(s);
	},false)
}
else if(window.localStorage.getItem('tbbg_welcome')!='1'){
	window.addEventListener('load',function(e){
		var s=document.createElement("script");
		s.src='http://ext.ccloli.com/tbbg/update2/welcome.php?help=1';
		document.body.appendChild(s);
	},false)
}
if((update==1)&&window.localStorage.getItem('TieBa-Background-CheckUpdate')!=new Date().getDate()){
	window.addEventListener('load',function(e){
		var s=document.createElement("script");
		s.src='http://ext.ccloli.com/tbbg/update2?v=1.2.11.7&t='+new Date().getTime();
		document.body.appendChild(s);
	},false)
}