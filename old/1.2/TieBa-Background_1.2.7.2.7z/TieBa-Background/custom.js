﻿/*TieBa-Background JS文件*/
/*By 为了活着 & 864907600cc*/
/*Thanks To 5B4B铅笔 & 寒云似雾*/

var img = 4;	//图片张数（默认4张，最多999张，设置为0即不开启图片背景）
var chgtime = 10;	//设置切换时间（以秒计,默认10秒，时限不限，设置为0即不开启图片切换）

/**若您不了解相关代码的含义，请勿修改以下代码**/
if(img>=1){
function replaceBG(e) {
	if ( e.url.indexOf('tie-day.css') > 0 || e.url.indexOf('tie-night.css') > 0)
		e.preventDefault();

	if ( document.body ) {
		//移除事件监听
		document.removeEventListener('beforeload', replaceBG, true);

		//随机选择背景图片
		var doc = document.body;
		//优化随机选择代码
		var num = parseInt(Math.random()*img+1);		
		doc.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;background-size:cover !important;';
		doc.style.backgroundAttachment = 'fixed';
		doc.style.backgroundPosition = 'center center';
		doc.style.backgroundRepeat = 'no-repeat';

		if (!document.getElementById("TieBa-Background")){
			//添加白色遮罩层
			num = document.createElement('div');
			num.className = 'TBBG_bg_white';
			num.id = 'TieBa-Background';
			doc.appendChild(num);
			seed = document.createElement('div');
			seed.className = 'TBBG_top_white';
			seed.id = 'TieBa-Background';
			doc.appendChild(seed); 	
		}
	
		//定时切换图片
		if (chgtime!="0"){
			setTimeout(function(){
				  replaceBG(e);
				  },chgtime*1000);
		}
	}
}

document.addEventListener('beforeload', replaceBG, true);

var a = document.getElementsByTagName('span');
for ( var i = a.length - 1 ; i > -1 ; i-- ) {
　if ( a[i].innerText == '精品' || a[i].innerText == '投票' ) {
　　if ( a[i].parentNode.className == 'thread_title' )
　　　a[i].parentNode.parentNode.parentNode.removeChild(a[i].parentNode.parentNode);
　}
}
}