﻿/*TieBa-Background JS文件*/
/*By 为了活着 & 864907600cc*/
/*Thanks To 5B4B铅笔 & 寒云似雾*/

var img = 4;		//图片张数（默认4张，最多999张，设置为0即不开启图片背景 [ 若 使用旧版本manifest文件 或 使用V22版本的Google Chrome并使用专用manifest 则无图片数限制 ] ）
var chgtime = 10;	//设置切换时间（以秒计,默认10秒，时限不限，设置为0即不开启图片切换）

/**若您不了解相关代码的含义，请勿修改以下代码**/
if(img>=1){
function replaceBG(e) {
	if ( e.url.indexOf('tie-day.css') > 0 || e.url.indexOf('tie-night.css') > 0)
		e.preventDefault();
	if ( document.body ) {
		document.removeEventListener('beforeload', replaceBG, true);
		var doc = document.body;
		var num = parseInt(Math.random()*img+1);
		doc.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;background-size:cover !important;';
		doc.style.backgroundAttachment = 'fixed';
		doc.style.backgroundPosition = 'center center';
		doc.style.backgroundRepeat = 'no-repeat';
		num = document.createElement('div');
		num.className = 'TBBG_bg_white';
		num.id = 'TieBa-Background';
		doc.appendChild(num);
		seed = document.createElement('div');
		seed.className = 'TBBG_top_white';
		seed.id = 'TieBa-Background';
		doc.appendChild(seed); 
		chg();
		function chg(){
		if (chgtime!="0"){			
			var num = parseInt(Math.random()*img+1);
			if (!document.getElementById('TieBa-Background-Reload')) {
				rel = document.createElement('div');
				rel.id = 'TieBa-Background-Reload';
				doc.appendChild(rel); 
			}
			rel.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;';
			setTimeout(function(){bg();},chgtime*1000);
			function bg(){
				doc.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;background-size:cover !important;';
				doc.style.backgroundAttachment = 'fixed';
				doc.style.backgroundPosition = 'center center';
				doc.style.backgroundRepeat = 'no-repeat';
				chg();
			}
		}
		}
	}
}	
(function(s){var x=document.createElement("style");x.textContent=s;x.type="text/css";x.id="fuck";document.documentElement.appendChild(x);})(".wrap1,.wrap2,.thread_theme_4{background:none !important}");
document.addEventListener('beforeload', replaceBG, true);
var a = document.getElementsByTagName('span');
for ( var i = a.length - 1 ; i > -1 ; i-- ) {
　if ( a[i].innerText == '精品' || a[i].innerText == '投票' ) {
　　if ( a[i].parentNode.className == 'thread_title' )
　　　a[i].parentNode.parentNode.parentNode.removeChild(a[i].parentNode.parentNode);
　}
}
}