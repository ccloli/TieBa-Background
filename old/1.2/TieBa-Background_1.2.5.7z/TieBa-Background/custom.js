﻿var img = 4;	//图片张数（默认4张，最多999张）

function replaceBG(e) {
	if ( e.url.indexOf('tie-day.css') > 0 || e.url.indexOf('tie-night.css') > 0)
		e.preventDefault();

	if ( document.body ) {
		//移除事件监听
		document.removeEventListener('beforeload', replaceBG, true);

		//随机选择背景图片
		var num = 999 / img;
		var seed = new Date().getMilliseconds();
		var doc = document.body;
		num = Math.round(seed / num);
		num = (num == 0) ? img : num;
		doc.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;';
		doc.style.backgroundAttachment = 'fixed';
		doc.style.backgroundPosition = 'center center';
		doc.style.backgroundRepeat = 'no-repeat';
		doc.style.backgroundSize = 'cover';

		//添加白色遮罩层
		num = document.createElement('div');
		num.className = 'TBBG_bg_white';
		doc.appendChild(num);
		seed = document.createElement('div');
		seed.className = 'TBBG_top_white';
		doc.appendChild(seed);
	}
}

document.addEventListener('beforeload', replaceBG, true);

var a = document.getElementsByTagName('span');
for ( var i = a.length - 1 ; i > -1 ; i-- ) {
　if ( a[i].innerText == '精品' || a[i].innerText == '投票' ) {
　　if ( a[i].parentNode.className == 'thread_title' )
　　　a[i].parentNode.parentNode.parentNode.removeChild(a[i].parentNode.parentNode);
　}
}