﻿var img = 4;	//图片张数（默认4张，最多999张）
var time = 10;	//设置切换时间（以秒计,默认10秒，时限不限）

function replaceBG(e) {
	if ( e.url.indexOf('tie-day.css') > 0 || e.url.indexOf('tie-night.css') > 0)
		e.preventDefault();

	if ( document.body ) {
		//移除事件监听
		document.removeEventListener('beforeload', replaceBG, true);

		//随机选择背景图片
		var doc = document.body;
		/*优化随机选择代码
		var num = 999 / img;
		var seed = new Date().getMilliseconds();
		num = Math.round(seed / num);
		num = (num == 0) ? img : num; */
		//优化后的随机选择代码
		var num = parseInt(Math.random()*img+1);
		doc.style.cssText = 'background-image: url(' + chrome.extension.getURL(num + '.jpg') + ') !important;';
		doc.style.backgroundAttachment = 'fixed';
		doc.style.backgroundPosition = 'center center';
		doc.style.backgroundRepeat = 'no-repeat';
		doc.style.backgroundSize = 'cover';

		if (!document.getElementById("TBBG")){
			//添加白色遮罩层
			num = document.createElement('div');
			num.className = 'TBBG_bg_white';
			num.id = 'TBBG';
			doc.appendChild(num);
			seed = document.createElement('div');
			seed.className = 'TBBG_top_white';
			doc.appendChild(seed); 	
		}
	
		//定时切换图片
		setTimeout(function(){
			  replaceBG(e);
			  },time*1000);
	}
}

document.addEventListener('beforeload', replaceBG, true);

var a = document.getElementsByTagName('span');
for ( var i = a.length - 1 ; i > -1 ; i-- ) {
　if ( a[i].innerText == '精品' || a[i].innerText == '投票' ) {
　　if ( a[i].parentNode.className == 'thread_title' )
　　　a[i].parentNode.parentNode.parentNode.removeChild(a[i].parentNode.parentNode);
　}
}